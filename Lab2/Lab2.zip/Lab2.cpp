#include <cstdint>
#include <cmath>
#include "engine.h"

int main()
{
    engine e{};
	e.start();
}
